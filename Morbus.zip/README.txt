Download Morbus.zip.
Extract.
To run, run start.batch.
